"""
Renewable EV Charging Station Plant Simulator

This is a starter simulator for an educational SCADA project.
It models:
- Solar PV generation
- Battery SOC
- Grid import/export
- Three EV chargers
- Emergency stop and grid outage conditions

Next development step:
Expose these values through Modbus TCP using pymodbus.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
import math
import random
import time


@dataclass
class Charger:
    name: str
    max_kw: float = 22.0
    plugged: bool = False
    demand_kw: float = 0.0
    actual_kw: float = 0.0


@dataclass
class PlantState:
    pv_kw: float = 0.0
    battery_soc_pct: float = 60.0
    battery_kw: float = 0.0  # positive = discharge, negative = charge
    grid_kw: float = 0.0     # positive = import, negative = export
    grid_available: bool = True
    emergency_stop: bool = False
    grid_import_limit_kw: float = 40.0
    chargers: list[Charger] = field(default_factory=list)
    alarms: list[str] = field(default_factory=list)


def solar_curve_kw(seconds: int, pv_peak_kw: float = 50.0) -> float:
    """Simple accelerated solar curve.

    One simulated day is compressed into 120 seconds.
    Output is zero at night and peaks around midday.
    """
    simulated_day_position = (seconds % 120) / 120.0
    sun = math.sin(math.pi * simulated_day_position)
    cloud_factor = random.uniform(0.85, 1.0)
    return max(0.0, pv_peak_kw * sun * cloud_factor)


def randomise_chargers(chargers: list[Charger]) -> None:
    """Randomly plug/unplug chargers and assign demand."""
    for charger in chargers:
        if random.random() < 0.03:
            charger.plugged = not charger.plugged
        charger.demand_kw = random.uniform(8.0, charger.max_kw) if charger.plugged else 0.0


def allocate_charger_power(state: PlantState) -> None:
    """Apply simple supervisory control.

    Priority:
    1. Emergency stop disables all chargers.
    2. Grid outage allows charging only from PV + safe battery discharge.
    3. Grid import limit caps total charging power.
    4. Power is split fairly across active chargers.
    """
    active = [c for c in state.chargers if c.plugged]

    if state.emergency_stop:
        for c in state.chargers:
            c.actual_kw = 0.0
        return

    total_demand = sum(c.demand_kw for c in active)

    if state.battery_soc_pct > 25.0:
        max_battery_discharge_kw = 20.0
    else:
        max_battery_discharge_kw = 0.0

    grid_allowance = state.grid_import_limit_kw if state.grid_available else 0.0
    available_for_charging = state.pv_kw + max_battery_discharge_kw + grid_allowance
    allowed_total = min(total_demand, available_for_charging)

    if not active:
        return

    if total_demand <= 0:
        for c in state.chargers:
            c.actual_kw = 0.0
        return

    # Proportional curtailment according to each charger's demand.
    for c in state.chargers:
        if c in active:
            c.actual_kw = allowed_total * (c.demand_kw / total_demand)
        else:
            c.actual_kw = 0.0


def update_energy_balance(state: PlantState, dt_seconds: float = 1.0) -> None:
    """Update battery and grid power based on charger load and PV."""
    charger_load_kw = sum(c.actual_kw for c in state.chargers)
    net_after_pv_kw = charger_load_kw - state.pv_kw

    if state.emergency_stop:
        state.battery_kw = 0.0
        state.grid_kw = 0.0
        return

    if net_after_pv_kw > 0:
        # Need extra power after PV.
        if state.battery_soc_pct > 25.0:
            state.battery_kw = min(20.0, net_after_pv_kw)
        else:
            state.battery_kw = 0.0
        remaining = net_after_pv_kw - state.battery_kw
        state.grid_kw = remaining if state.grid_available else 0.0
    else:
        # Excess PV. Charge battery first, then export.
        excess_kw = abs(net_after_pv_kw)
        if state.battery_soc_pct < 95.0:
            state.battery_kw = -min(15.0, excess_kw)
        else:
            state.battery_kw = 0.0
        remaining_excess = excess_kw - abs(state.battery_kw)
        state.grid_kw = -remaining_excess if state.grid_available else 0.0

    # Very simplified SOC update. Positive battery_kw discharges battery.
    battery_capacity_kwh = 80.0
    delta_soc = (state.battery_kw * dt_seconds / 3600.0) / battery_capacity_kwh * 100.0
    state.battery_soc_pct = max(0.0, min(100.0, state.battery_soc_pct - delta_soc))


def update_alarms(state: PlantState) -> None:
    alarms = []
    if state.emergency_stop:
        alarms.append("EMERGENCY_STOP_ACTIVE")
    if not state.grid_available:
        alarms.append("GRID_UNAVAILABLE")
    if state.battery_soc_pct < 20.0:
        alarms.append("LOW_BATTERY_SOC")
    if state.grid_kw > state.grid_import_limit_kw + 0.5:
        alarms.append("GRID_IMPORT_LIMIT_EXCEEDED")
    if state.pv_kw < 5.0 and sum(c.actual_kw for c in state.chargers) > 20.0:
        alarms.append("LOW_RENEWABLE_SUPPLY")
    state.alarms = alarms


def print_state(state: PlantState) -> None:
    now = datetime.now().strftime("%H:%M:%S")
    charger_text = " | ".join(
        f"{c.name}: plugged={c.plugged} demand={c.demand_kw:4.1f}kW actual={c.actual_kw:4.1f}kW"
        for c in state.chargers
    )
    alarms = ", ".join(state.alarms) if state.alarms else "NORMAL"
    print(
        f"[{now}] PV={state.pv_kw:5.1f}kW | "
        f"Battery={state.battery_soc_pct:5.1f}% ({state.battery_kw:+5.1f}kW) | "
        f"Grid={state.grid_kw:+5.1f}kW | Alarms={alarms}\n"
        f"        {charger_text}"
    )


def main() -> None:
    state = PlantState(
        chargers=[
            Charger("EVSE-1"),
            Charger("EVSE-2"),
            Charger("EVSE-3"),
        ]
    )

    print("Renewable EV Charging Station Simulator")
    print("Press Ctrl+C to stop.\n")

    t = 0
    try:
        while True:
            state.pv_kw = solar_curve_kw(t)

            # Random demo events.
            if random.random() < 0.01:
                state.grid_available = not state.grid_available
            if random.random() < 0.005:
                state.emergency_stop = not state.emergency_stop

            randomise_chargers(state.chargers)
            allocate_charger_power(state)
            update_energy_balance(state)
            update_alarms(state)
            print_state(state)

            t += 1
            time.sleep(1)
    except KeyboardInterrupt:
        print("\nSimulator stopped.")


if __name__ == "__main__":
    main()
