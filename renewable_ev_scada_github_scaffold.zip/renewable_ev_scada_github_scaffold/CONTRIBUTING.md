# Contributing

This is a personal educational project. Suggestions are welcome, especially around:

- Modbus register mapping
- OpenPLC implementation
- Ignition HMI design
- EV charging load-balancing logic
- Renewable energy simulation improvements
