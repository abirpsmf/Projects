# Control Logic Plan

## Control Objectives

1. Keep the EV charging station within the grid import limit.
2. Prefer solar PV before grid import.
3. Use battery power when SOC is healthy.
4. Protect the battery from deep discharge.
5. Disable chargers during emergency stop.
6. Disable or curtail chargers during grid outage.
7. Share available power fairly between active chargers.

## Suggested PLC Logic Split

### Ladder Diagram

Use ladder for simple interlocks:

- Emergency stop
- Charger plugged status
- Grid available status
- Charger enable coils
- Alarm coils

### Structured Text

Use Structured Text for calculations:

- Total charger demand
- Available power calculation
- Power curtailment
- Fair power split
- Battery SOC logic

## Basic Logic

```text
IF emergency_stop THEN
    disable all chargers
    charger limits = 0
END_IF

IF battery_soc < 20% THEN
    battery_discharge_allowed = false
END_IF

available_power = pv_power + grid_import_limit + battery_available_power

IF total_charger_demand > available_power THEN
    curtail chargers proportionally
ELSE
    allow requested charger demand
END_IF
```

## Alarm Conditions

| Alarm | Condition |
|---|---|
| Emergency stop active | EMERGENCY_STOP = TRUE |
| Grid unavailable | GRID_AVAILABLE = FALSE |
| Low battery SOC | BATTERY_SOC < 20% |
| Battery reserve warning | BATTERY_SOC < 30% |
| Grid import high | GRID_POWER > GRID_IMPORT_LIMIT |
| Charger curtailed | ACTUAL_POWER < DEMAND_POWER |
