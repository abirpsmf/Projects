# Test Plan

## Scenario 1: Normal Daytime Charging

Inputs:

- PV generation above 30 kW
- Grid available
- Battery SOC above 50%
- One or two chargers active

Expected result:

- Chargers receive requested power
- Grid import is low
- No alarms active

## Scenario 2: All Chargers Full Demand

Inputs:

- Three chargers plugged
- Each charger demands 22 kW
- Grid import limit set to 40 kW

Expected result:

- Total charger power is limited by PV + battery + grid limit
- Curtailment occurs if demand exceeds available power

## Scenario 3: Low Battery SOC

Inputs:

- Battery SOC below 20%
- Charger demand active

Expected result:

- Battery discharge is disabled
- Low battery alarm is active
- Chargers rely on PV and grid only

## Scenario 4: Grid Outage

Inputs:

- Grid unavailable
- Chargers plugged

Expected result:

- Grid import becomes zero
- Chargers only run if PV and battery can support them
- Grid unavailable alarm is active

## Scenario 5: Emergency Stop

Inputs:

- Emergency stop active

Expected result:

- All charger outputs go to zero
- Emergency stop alarm is active
- Operator must reset emergency stop before charging resumes

## Scenario 6: Demand-Response Event

Inputs:

- Grid import limit reduced from 40 kW to 15 kW
- All chargers active

Expected result:

- Charger power is curtailed
- Grid import stays near or below the limit
