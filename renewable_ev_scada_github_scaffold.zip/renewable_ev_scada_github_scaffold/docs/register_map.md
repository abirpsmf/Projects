# Modbus Register Map

This register map is the planned interface between the Python simulator and OpenPLC.

Values are scaled by 10 where decimals are needed.

Example:

```text
357 means 35.7 kW
684 means 68.4 % SOC
```

## Holding Registers: Measurements and Setpoints

| Address | Name | Direction | Scale | Unit | Description |
|---:|---|---|---:|---|---|
| 40001 | PV_POWER | Simulator → PLC | ×10 | kW | Solar PV output |
| 40002 | BATTERY_SOC | Simulator → PLC | ×10 | % | Battery state of charge |
| 40003 | BATTERY_POWER | Simulator → PLC | ×10 | kW | Positive = discharge, negative = charge |
| 40004 | GRID_POWER | Simulator → PLC | ×10 | kW | Positive = import, negative = export |
| 40005 | CHG1_DEMAND | Simulator → PLC | ×10 | kW | Charger 1 requested power |
| 40006 | CHG2_DEMAND | Simulator → PLC | ×10 | kW | Charger 2 requested power |
| 40007 | CHG3_DEMAND | Simulator → PLC | ×10 | kW | Charger 3 requested power |
| 40008 | CHG1_ACTUAL | Simulator → PLC | ×10 | kW | Charger 1 actual delivered power |
| 40009 | CHG2_ACTUAL | Simulator → PLC | ×10 | kW | Charger 2 actual delivered power |
| 40010 | CHG3_ACTUAL | Simulator → PLC | ×10 | kW | Charger 3 actual delivered power |
| 40011 | GRID_IMPORT_LIMIT | HMI/PLC → Simulator | ×10 | kW | Demand-response import limit |
| 40012 | CHG1_LIMIT | PLC → Simulator | ×10 | kW | Charger 1 power limit command |
| 40013 | CHG2_LIMIT | PLC → Simulator | ×10 | kW | Charger 2 power limit command |
| 40014 | CHG3_LIMIT | PLC → Simulator | ×10 | kW | Charger 3 power limit command |

## Coils / Discrete Signals

| Address | Name | Direction | Description |
|---:|---|---|---|
| 00001 | EMERGENCY_STOP | HMI/Simulator → PLC | Emergency stop active |
| 00002 | GRID_AVAILABLE | Simulator → PLC | Grid supply available |
| 00003 | CHG1_PLUGGED | Simulator → PLC | Charger 1 vehicle connected |
| 00004 | CHG2_PLUGGED | Simulator → PLC | Charger 2 vehicle connected |
| 00005 | CHG3_PLUGGED | Simulator → PLC | Charger 3 vehicle connected |
| 00006 | CHG1_ENABLE | PLC → Simulator | Charger 1 enable command |
| 00007 | CHG2_ENABLE | PLC → Simulator | Charger 2 enable command |
| 00008 | CHG3_ENABLE | PLC → Simulator | Charger 3 enable command |

## Notes

- The exact addressing may need adjustment depending on OpenPLC and Modbus client settings.
- Signed values such as battery power and grid power may require signed integer handling.
- This map is intentionally simple for an educational prototype.
