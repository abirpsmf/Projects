# Ignition HMI Plan

## Screen 1: Site Overview

Display a one-line mimic of:

```text
Solar PV → Site Bus → EV Chargers
Battery ↔ Site Bus
Grid ↔ Site Bus
```

Show:

- PV power
- Battery SOC
- Battery charge/discharge power
- Grid import/export
- Total EV charger load
- Current grid import limit
- Alarm banner

## Screen 2: Charger Status

Show each charger:

- Plugged status
- Demand kW
- Actual output kW
- Enable status
- Curtailed status

## Screen 3: Battery and PV

Show:

- PV generation trend
- Battery SOC trend
- Battery power trend
- Battery low-SOC warning

## Screen 4: Grid and Demand Response

Show:

- Grid import/export
- Grid import limit
- Load curtailment status
- Grid outage state

## Screen 5: Alarms

Alarm list:

- Emergency stop active
- Grid unavailable
- Low battery SOC
- Grid import limit exceeded
- Charger curtailed

## Suggested Tags

See `ignition/tag_list_plan.csv` for planned tag names.
