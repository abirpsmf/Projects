# System Architecture

## Overview

The project represents a renewable-powered EV charging station with:

- Solar PV generation
- Battery energy storage
- Grid connection
- Three EV chargers
- PLC control layer
- SCADA/HMI layer

The system is designed as a simulation because no physical EV charger, inverter, battery, or PLC hardware is available.

## Architecture

```text
+--------------------------+
| Python Plant Simulator   |
| - PV model               |
| - Battery SOC model      |
| - Grid model             |
| - 3 EV chargers          |
+-------------+------------+
              |
              | Modbus TCP registers
              v
+--------------------------+
| OpenPLC Runtime          |
| - Safety interlocks      |
| - Load balancing         |
| - Demand response        |
| - Battery SOC protection |
+-------------+------------+
              |
              | OPC-UA tags / Ignition OPC server
              v
+--------------------------+
| Ignition SCADA           |
| - HMI overview           |
| - Trends                 |
| - Alarms                 |
| - Historian              |
+--------------------------+
```

## Data Flow

1. The Python simulator calculates plant values every second.
2. Simulated measurements are exposed as Modbus registers.
3. OpenPLC reads the registers and runs control logic.
4. OpenPLC writes control commands such as charger enable signals and charger power limits.
5. Ignition displays live tags, trends, alarms, and operator controls.

## Main Engineering Ideas

- Renewable self-consumption: use solar PV for charging before importing from the grid.
- Battery dispatch: use the battery to reduce grid demand when SOC is healthy.
- Demand response: curtail charger power if the grid import limit is exceeded.
- Safety interlocking: emergency stop and grid outage states disable unsafe charging.
- Historical analysis: trend PV, battery SOC, grid import, and charger power over time.
