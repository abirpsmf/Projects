# CV Bullet Options

## Safe Current Version While Project Is In Progress

- Developing a renewable EV charging SCADA prototype using a Python plant simulator, Modbus TCP register-map design, OpenPLC control logic planning, and Ignition HMI architecture.
- Designed a simulated solar PV, battery, grid, and three-charger EV charging station model with planned PLC interlocks, demand-response control, load balancing, alarms, and historical trend logging.

## Strong Version After Simulator + Modbus Are Working

- Built a Python-based renewable EV charging station simulator exposing PV, battery, grid, and EVSE telemetry through a Modbus TCP register map for PLC/SCADA integration.
- Implemented simulated PV generation, battery SOC behaviour, grid import/export calculation, three EV charger loads, emergency stop states, and demand-response test scenarios.

## Strong Version After OpenPLC Is Connected

- Integrated a Python EV charging plant simulator with OpenPLC using Modbus TCP and implemented PLC-style interlocks for emergency stop, grid outage, low battery SOC, and charger enable logic.
- Developed structured text logic for charger load balancing, grid import limiting, and battery SOC protection in a simulated renewable EV charging station.

## Strong Version After Ignition HMI Is Built

- Developed an Ignition SCADA HMI for a simulated renewable EV charging station, including site overview mimic, charger status screens, alarm visualization, and historical trends.
- Built an end-to-end SCADA prototype connecting a Python plant simulator, OpenPLC control layer, Modbus TCP telemetry, and Ignition HMI for renewable EV charging demand-response testing.

## Do Not Claim Unless Actually Done

- Commissioned a real EV charging station.
- Integrated physical PLC hardware.
- Implemented certified OCPP communication.
- Controlled real inverters, batteries, or EV chargers.
- Deployed a production SCADA system.
