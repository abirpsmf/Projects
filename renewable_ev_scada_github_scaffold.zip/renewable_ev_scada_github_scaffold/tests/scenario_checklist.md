# Scenario Checklist

Use this file while recording screenshots or a demo video.

## Baseline

- [ ] Simulator starts without errors
- [ ] PV output changes over time
- [ ] Battery SOC changes over time
- [ ] Charger plugged/unplugged states change
- [ ] Grid import/export calculation is visible

## Control Behaviour

- [ ] Emergency stop disables all charger outputs
- [ ] Low battery SOC prevents battery discharge
- [ ] Grid outage prevents grid import
- [ ] Charger load is curtailed when demand exceeds available power
- [ ] Three active chargers share available power fairly

## SCADA/HMI Behaviour

- [ ] HMI overview shows PV, battery, grid, and charger values
- [ ] Alarm banner shows active alarms
- [ ] Trend screen logs PV, SOC, grid import, and charger load
- [ ] Operator can change grid import limit

## Evidence for GitHub

- [ ] Screenshot: simulator console
- [ ] Screenshot: register map or tags
- [ ] Screenshot: HMI overview
- [ ] Screenshot: alarm condition
- [ ] Screenshot: trend/historian view
- [ ] Short demo video added or linked
