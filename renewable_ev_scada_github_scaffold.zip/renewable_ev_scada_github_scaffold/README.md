# Renewable-Powered EV Charging Station SCADA Prototype

A SCADA-style simulation project for a solar PV + battery-assisted EV charging station. The project models PV generation, battery state of charge, grid import/export, and three EV chargers, then exposes the system through an industrial-style architecture using Modbus TCP, PLC control logic, and an Ignition HMI.

> **Status:** In progress / educational prototype. The current repository contains the project scaffold, simulator starter code, register map, control logic plan, HMI plan, and testing checklist. Industrial integrations are being built incrementally.

---

## Project Goals

- Simulate a renewable-powered EV charging station with solar PV, battery storage, grid connection, and three EV chargers.
- Expose simulated field values through a Modbus TCP register map.
- Use OpenPLC for PLC-style interlocks, load balancing, and demand-response control.
- Use Ignition for HMI screens, alarms, trends, and operator-facing visualization.
- Log historical data for analysis and demo purposes.
- Test edge cases such as grid outage, low battery SOC, emergency stop, and all chargers operating at full demand.

---

## Proposed Architecture

```mermaid
flowchart LR
    A[Python Plant Simulator\nPV + Battery + Grid + 3 EV Chargers] -->|Modbus TCP Registers| B[OpenPLC Runtime\nLadder/ST Control Logic]
    B -->|Commands / Limits| A
    B -->|OPC-UA / Tags| C[Ignition SCADA]
    C --> D[HMI Overview]
    C --> E[Alarms]
    C --> F[Trends / Historian]
```

Simplified flow:

```text
Python simulator → Modbus TCP → OpenPLC → Ignition HMI / alarms / trends
```

---

## Current Repository Contents

```text
.
├── src/
│   └── simulator.py              # Starter plant simulator
├── docs/
│   ├── architecture.md           # System architecture explanation
│   ├── register_map.md           # Planned Modbus register map
│   ├── control_logic.md          # PLC control logic plan
│   ├── hmi_plan.md               # Ignition HMI screen plan
│   ├── test_plan.md              # Edge-case testing checklist
│   └── cv_bullets.md             # CV-safe project descriptions
├── openplc/
│   └── structured_text_pseudocode.st
├── ignition/
│   └── tag_list_plan.csv
├── tests/
│   └── scenario_checklist.md
├── requirements.txt
├── requirements-optional.txt
├── .gitignore
└── LICENSE
```

---

## Quick Start

Run the starter simulator:

```bash
python src/simulator.py
```

The simulator prints live values for:

- Solar PV power
- Battery SOC
- Battery charge/discharge power
- Grid import/export
- Three EV charger demands
- Three EV charger actual outputs
- Alarm states

---

## Main Features Planned

### Plant Simulation

- Solar PV daily generation curve
- Battery SOC model
- Grid import/export calculation
- Three EV chargers with variable demand
- Plugged/unplugged charger states
- Emergency stop input
- Grid outage simulation

### PLC Logic

- Emergency stop interlock
- Grid outage interlock
- Battery low-SOC protection
- Charger enable/disable logic
- Charger load balancing
- Grid import limiting
- Demand-response curtailment

### SCADA / HMI

- Site overview mimic
- PV, battery, grid, and charger values
- Alarm banner
- Trend screens
- Charger status screen
- Operator controls for demand limit and emergency stop

---

## Example Engineering Scenario

If EV demand is higher than available renewable + grid-limited power, the controller curtails the charger outputs.

Example:

```text
PV generation       = 20 kW
Battery available   = 10 kW
Grid import limit   = 30 kW
Total EV demand     = 66 kW
Available power     = 60 kW
Curtailment needed  = 6 kW
```

The PLC should distribute the available 60 kW across the active chargers.

---

## Limitations

This is an educational simulation project. It does not control real EV chargers, inverters, batteries, switchgear, or protection equipment. Safety-critical EV infrastructure requires certified hardware, electrical protection design, and compliance with relevant standards.

---

## Future Improvements

- Complete Modbus TCP server in the Python simulator
- Connect simulator to OpenPLC Runtime
- Implement ladder diagram and structured text control logic
- Build Ignition Vision/Perspective HMI screens
- Add SQLite or InfluxDB historian
- Add demo video and screenshots
- Add Docker Compose for easier setup
- Add OCPP-aware documentation as a future charging-station integration concept

---

## CV-Safe Summary

Developed a SCADA-style renewable EV charging station prototype using a Python-based plant simulator, planned Modbus TCP register map, PLC control logic design, and Ignition HMI architecture. The project models PV generation, battery SOC, grid import, charger demand, emergency-stop interlocks, grid import limiting, demand-response curtailment, alarm handling, and historical trend logging.
